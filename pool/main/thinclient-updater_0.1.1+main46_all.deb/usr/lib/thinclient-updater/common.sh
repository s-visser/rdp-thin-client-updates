# Shared by the update scripts. Sourced, not run.
# shellcheck shell=bash disable=SC2034
#
# Kept separate from the sign-in screen package on purpose: even when that
# package is broken, these scripts keep running and can install the fix.

# Settings: built-in defaults, then site.conf and local.conf (see
# /usr/lib/thinclient/load-config.sh). Read directly so the updater does not
# depend on the thinclient package.
UPDATE_URL=""
UPDATE_CHANNEL="stable"
NIGHTLY_REBOOT="always"
for file in /usr/lib/thinclient/defaults.conf /etc/thinclient/site.conf /etc/thinclient/local.conf; do
    if [ -r "$file" ]; then
        # shellcheck disable=SC1090
        . "$file"
    fi
done
unset file

UPDATER_KEYRING=/usr/share/keyrings/thinclient-archive-keyring.gpg
UPDATER_SOURCES=/etc/apt/sources.list.d/thinclient.list
UPDATER_STATE=/var/lib/thinclient-updater
# Set after an emergency update; cleared by the restart itself (/run is a tmpfs).
EMERGENCY_REBOOT_FLAG=/run/thinclient-emergency-reboot

# True on the live USB stick, which never updates or restarts by itself.
is_live_system() {
    [ -d /run/live/medium ]
}

session_active() {
    pgrep -x 'xfreerdp3|sdl-freerdp3|wlfreerdp3' >/dev/null
}

updates_running() {
    pgrep -f '/usr/bin/unattended-upgrade' >/dev/null || pgrep -x 'apt|apt-get|dpkg' >/dev/null
}

# Writes (or removes) the apt source of the thin client update channel from
# UPDATE_URL and UPDATE_CHANNEL. Returns 1 when the channel is not configured.
write_update_source() {
    local url=${UPDATE_URL%/} line
    if [ -z "$url" ] || [ ! -s "$UPDATER_KEYRING" ]; then
        rm -f "$UPDATER_SOURCES"
        return 1
    fi
    line="deb [signed-by=$UPDATER_KEYRING] $url ${UPDATE_CHANNEL:-stable} main"
    if [ "$(cat "$UPDATER_SOURCES" 2>/dev/null)" != "$line" ]; then
        echo "$line" >"$UPDATER_SOURCES"
    fi
}

# The InRelease file apt keeps for our channel; only present when its
# signature was valid. apt names list files after the URL without the scheme,
# with / replaced by _.
update_release_file() {
    local uri=${UPDATE_URL%/}/dists/${UPDATE_CHANNEL:-stable}/InRelease
    uri=${uri#*://}
    echo "/var/lib/apt/lists/${uri//\//_}"
}
