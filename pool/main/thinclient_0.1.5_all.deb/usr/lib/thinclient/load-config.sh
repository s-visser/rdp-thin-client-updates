# Sourced by the thin client scripts: built-in defaults, then the settings
# built into the ISO (site.conf), then the ones changed on the settings page
# (local.conf).
set -a
. /usr/lib/thinclient/defaults.conf
for file in /etc/thinclient/site.conf /etc/thinclient/local.conf; do
    if [ -r "$file" ]; then
        # shellcheck disable=SC1090
        . "$file"
    fi
done
unset file
set +a
